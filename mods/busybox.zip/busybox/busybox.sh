#!/bin/sh

if [ ! -f /system/xbin/busybox ]; then
	busybox cp tmp/busybox /system/xbin/busybox
fi
busybox chmod 0755 /system/xbin/busybox
busybox chown 0:2000 /system/xbin/busybox
/system/xbin/busybox --install -s /system/xbin
